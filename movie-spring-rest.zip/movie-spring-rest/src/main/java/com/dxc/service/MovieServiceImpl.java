package com.dxc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.dao.MovieDAO;
import com.dxc.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {
	@Autowired
	MovieDAO movieDAO;

	@Override
	public boolean addMovie(Movie movie) {
		movieDAO.addMovie(movie);
		return false;
	}

	@Override
	public Movie getMovie(int movieId) {
		return movieDAO.getMovie(movieId);
	}

	@Override
	public boolean isMovieExists(int movieId) {

		return movieDAO.isMovieExists(movieId);
	}

	@Override
	public boolean deleteMovie(int movieId) {

		return movieDAO.deleteMovie(movieId);
	}

	@Override
	public boolean updateMovie(Movie movie) {

		return movieDAO.updateMovie(movie);
	}

	@Override
	public List<Movie> getMovies() {
		
		return movieDAO.getMovies();
	}

	@Override
	public List<Movie> searchMovieByName(String movieName) {
		
		return movieDAO.searchMovieByName(movieName);
	}

}
