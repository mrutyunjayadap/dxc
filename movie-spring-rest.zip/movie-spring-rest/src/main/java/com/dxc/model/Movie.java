package com.dxc.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Movie {
	@Id
	private int movieId;
	private String movieName;
	private int budget;
	private String directorName;
	public Movie() {
		super();
	}
	public Movie(int movieId, String movieName, int budget, String directorName) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.budget = budget;
		this.directorName = directorName;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public int getBudget() {
		return budget;
	}
	public void setBudget(int budget) {
		this.budget = budget;
	}
	public String getDirectorName() {
		return directorName;
	}
	public void setDirectorName(String directorName) {
		this.directorName = directorName;
	}
	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", budget=" + budget + ", directorName="
				+ directorName + "]";
	}

}
