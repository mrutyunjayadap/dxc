import React, { Component } from "react";
/* import './ProductValidation.css' */
import ProductDisplay from "./ProductDisplay";
import ProductList from "./ProductList"
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
class productForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      quantityOnHand: "",
      errors: {
        quantityOnHand: ""
      },
      productList : [
        {
          productId: 1001,
          productName: "Watch",
          quantityOnHand: 2000,
          price: 10000
        },
        {
          productId: 1002,
          productName: "Mouse",
          quantityOnHand: 29,
          price: 180000
        },
        {
          productId: 1003,
          productName: "Laptop",
          quantityOnHand: 29,
          price: 122
        },
        {
          productId: 10113,
          productName: "Presenter",
          quantityOnHand: 29,
          price: 122
        },
  
        {
          productId: 111003,
          productName: "Marker",
          quantityOnHand: 29,
          price: 122
        }
      ]
    };
  }
  doValidation = e => {
    e.preventDefault();
    const { name, value } = e.target;
    let errors = this.state.errors;
    switch (name) {
      case "quantityOnHand":
        if ((errors.quantityOnHand = value.length == 0)) {
          errors.quantityOnHand = "quantityOnHand cannot be 0";
        } else if ((errors.quantityOnHand = value < 0)) {
          errors.quantityOnHand = "quantityOnHand cannot be Negative";
        } else break;
      default:
        break;
    }
    this.setState({
      errors,
      [name]: value
    });

    const{id,quantity,productList}=this.state
    var prodlist=productList
    prodlist[productList.findIndex(x=>x.productId==id)].quantityOnHand=quantity;
    this.setState({
        productList:prodlist
    })

  };

 

  render() {
    const productList = [
        {
          productId: 1001,
          productName: "Watch",
          quantityOnHand: 2000,
          price: 10000
        },
        {
          productId: 1002,
          productName: "Mouse",
          quantityOnHand: 29,
          price: 180000
        },
        {
          productId: 1003,
          productName: "Laptop",
          quantityOnHand: 29,
          price: 122
        },
        {
          productId: 10113,
          productName: "Presenter",
          quantityOnHand: 29,
          price: 122
        },
  
        {
          productId: 111003,
          productName: "Marker",
          quantityOnHand: 29,
          price: 122
        }
      ];

    return (
      <div>
        {productList.map((product, index) => (
          <Link to={`${this.props.match.url}/` + product.productName}>
            <ProductDisplay
              render={({ match }) => (match = { match })}
              nn={index}
              key={index}
              product={product}
            ></ProductDisplay>
          </Link>
        ))}

        <div className="wrapper">
          <div className="form-wrapper">
            <h2>Enter Details</h2>
            <form onSubmit="this.doValidation">
              <div className="productId">
                <label htmlFor="productId">ProductId :</label>
                <input type="text" name="productId" />
                <span className="error">{this.state.errors.productId}</span>
              </div>
              <div className="quantityOnHand">
                <label htmlFor="quantityOnHand">Quantity :</label>
                <input
                  type="text"
                  name="quantityOnHand"
                  onChange={this.doValidation}
                />
                <br />
                <span className="error">
                  {this.state.errors.quantityOnHand}
                </span>
              </div>
              <div className="submit">
                <input type="submit" />
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default productForm;
