package inheritanceAssign;

public class Bus extends Vehicle {
	private int numberOfSeats;

	public Bus() {
		// TODO Auto-generated constructor stub
	}

	public Bus(String color, int model, int numOfWheels) {
		super(color, model, numOfWheels);
		// TODO Auto-generated constructor stub
	}

	public Bus(int numberOfSeats) {
		super();
		this.numberOfSeats = numberOfSeats;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	@Override
	public String toString() {
		return "Bus [numberOfSeats=" + numberOfSeats + ", getColor()=" + getColor() + ", getModel()=" + getModel()
				+ ", getNumOfWheels()=" + getNumOfWheels() + "]";
	}
	
	

}
