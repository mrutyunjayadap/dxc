package inheritanceAssign;

public class Road {

	public static void main(String[] args) {
		Truck t= new Truck("black", 320, 8);
		t.setLuggageCapacity(800);
		System.out.println(t);

		Bus b=new Bus("yellow", 450, 6);
		b.setNumberOfSeats(60);
		System.out.println(b);
		
		Car c=new Car("red", 220, 4);
		c.setTopSpeed(320);
		System.out.println(c);
	}

}
