package inheritanceAssign;

public class Truck extends Vehicle {
	private int luggageCapacity;

	public Truck() {
		// TODO Auto-generated constructor stub
	}

	public Truck(String color, int model, int numOfWheels) {
		super(color, model, numOfWheels);
		// TODO Auto-generated constructor stub
	}

	public Truck(int luggageCapacity) {
		super();
		this.luggageCapacity = luggageCapacity;
	}

	public int getLuggageCapacity() {
		return luggageCapacity;
	}

	public void setLuggageCapacity(int luggageCapacity) {
		this.luggageCapacity = luggageCapacity;
	}

	@Override
	public String toString() {
		return "Truck [luggageCapacity=" + luggageCapacity + ", getColor()=" + getColor() + ", getModel()=" + getModel()
				+ ", getNumOfWheels()=" + getNumOfWheels() + "]";
	}
	
	

}
