package inheritanceAssign;

public class Vehicle {
	private String color;
	private int model;
	private int numOfWheels;
	
	public Vehicle() {
		super();
	}

	public Vehicle(String color, int model, int numOfWheels) {
		super();
		this.color = color;
		this.model = model;
		this.numOfWheels = numOfWheels;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public int getNumOfWheels() {
		return numOfWheels;
	}

	public void setNumOfWheels(int numOfWheels) {
		this.numOfWheels = numOfWheels;
	}

	@Override
	public String toString() {
		return "Vehicle [color=" + color + ", model=" + model + ", numOfWheels=" + numOfWheels + "]";
	}
	
	

}
