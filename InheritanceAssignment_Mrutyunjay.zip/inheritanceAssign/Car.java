package inheritanceAssign;

public class Car extends Vehicle {
	private int topSpeed;

	public Car() {
		// TODO Auto-generated constructor stub
	}

	public Car(String color, int model, int numOfWheels) {
		super(color, model, numOfWheels);
		// TODO Auto-generated constructor stub
	}

	public Car(int topSpeed) {
		super();
		this.topSpeed = topSpeed;
	}

	public int getTopSpeed() {
		return topSpeed;
	}

	public void setTopSpeed(int topSpeed) {
		this.topSpeed = topSpeed;
	}

	@Override
	public String toString() {
		return "Car [topSpeed=" + topSpeed + ", getColor()=" + getColor() + ", getModel()=" + getModel()
				+ ", getNumOfWheels()=" + getNumOfWheels() + "]";
	}
	
	

}
