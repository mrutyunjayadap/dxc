import axios from 'axios';
const FEEDBACK_API_URL="http://localhost:8080/ClientTrackingApplication/clientFeedback"
class FeedbackDataService{
    addFeedback(visitId,feedback){
        return axios.post(`${FEEDBACK_API_URL}/${visitId}/feedback/`,feedback)
    }
    editFeedback(feedback){
        return axios.put(`${FEEDBACK_API_URL}`,feedback)
    }
    deleteFeedback(visitId,feedbackIdToDelete){
        return axios.delete(`${FEEDBACK_API_URL}/${visitId}/feedback/${feedbackIdToDelete}/`)
    }
    getFeedbackById(visitId,feedbackId){
        return axios.get(`${FEEDBACK_API_URL}/${visitId}/feedback/${feedbackId}/`)
    }
}
export default new FeedbackDataService()