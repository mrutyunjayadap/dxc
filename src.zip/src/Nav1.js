import React, { Component } from 'react';
import './Nav1.css'

import {Redirect} from 'react-router-dom'
class NavSearchBar extends Component {
  constructor(props) {
    super(props);
    const token = localStorage.getItem("token")
        let loggedIn = true

        if (token == null) {
            loggedIn = false
        }
        this.state = {
          chapterName:'',
          loggedIn
        }
        this.OnSubmit=this.OnSubmit.bind(this)

  }

  OnSubmit() {
    localStorage.clear()
    // this.props.history.push("/")
    window.location.href="/"
  }

  
  render(){
    if (this.state.loggedIn === false) {
      return <Redirect to="/"></Redirect>
    }
    return(
    <div>
      <ul>
      <li><a class="active" href="/upcomingclientvisit">Home</a></li>
        <li class="dropdown">
          <a href="javascript:void(0)" class="dropbtn">Add</a>
            <div class="dropdown-content">
              <a href="/addClient">Add Client</a>
              <a href="/addProject">Add Project</a>
              <a href="/addClientVisitDetails">Add Client Visit</a>
            </div>
        </li>
        <li class="dropdown">
          <a href="javascript:void(0)" class="dropbtn">Details</a>
            <div class="dropdown-content">
              <a href="/viewClientDetails">Client Details</a>
              <a href="/viewProjectDetails">Project Details</a>
              <a href="/viewClientVisitDetails">All Client Visits </a>
            </div>
        </li>
      
        <li><a href="/completedVisits">Completed Visits</a></li>
        <li><a href="/viewCancelledVisits">Cancelled Visits</a></li>
        <li style={{float:"right"}}>
          <button className="logout" onClick={() => this.OnSubmit()}>Logout</button>
        </li>
    </ul>
  </div>
    )
  }
}

export default NavSearchBar;