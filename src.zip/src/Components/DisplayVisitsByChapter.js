import React, { Component } from 'react';
import '../App.css';
import ClientVisitDataService from '../Service/ClientVisitDataService';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';

import Nav1 from '../Nav1';

class DisplayVisitsByChapter extends Component {
    constructor(props) {
        super(props);

        this.state = ({
            clientVisits: [],
            chapterToWhichBelongs:this.props.match.params.chapterName,
            message: ''
        })
    }

    componentWillMount() {
        console.log(this.state.chapterToWhichBelongs)
        ClientVisitDataService.searchByChapter(this.state.chapterToWhichBelongs).then(
            response => {
                console.log(response)
                this.setState({
                    clientVisits: response.data
                })

            }

        )
    }

    render() {
        return (
            <div>
                <img src={dxc} class="logo"></img>
                 <b>DXC Client Visit App</b>
                <Nav1></Nav1>
                
            <div className="bootstrap-iso">

                <div className="container">
                    
                    <h2>Visits By chapter</h2>
                    {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
                    <div className="container">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>VisitId</th>
                                    <th>DateOfVisit</th>
                                    <th>Client</th>
                                    {/* list of projects */}
                                    <th>ProjectToVisit</th> 
                                    {/* list of feedbacks */}
                                    <th>ClientFeedbacks</th> 
                                    

                                </tr>

                            </thead>
                            <tbody>
                                {
                                    this.state.clientVisits.map(clientVisit =>
                                        <tr key={clientVisit.visitId}>
                                            <td>{clientVisit.visitId}</td>
                                            <td>{clientVisit.dateOfVisit}</td>
                                            <td id="client"><tr>ClientId:{clientVisit.client.clientId}</tr>
                                                <tr>CompanyName:{clientVisit.client.clientCompanyName}</tr>
                                                <tr>RepresentativeName:{clientVisit.client.representativeName}</tr>
                                                <tr>Location:{clientVisit.client.location}</tr>
                                                <tr>Contact No:{clientVisit.client.mobileNumber}</tr>
                                                <tr>Email:{clientVisit.client.emailAddress}</tr>

                                            </td>
                                            <td>{clientVisit.projectToVisit.map(project => (
                                                <tr id="project">
                                                    <tr>ProjectName:{project.projectName}</tr>
                                                    <tr>ChapterName:{project.chapterToWhichBelongs}</tr>
                                                    <tr>ProjectManager:{project.projectManager}</tr>
                                                    <tr>ProjectVersion:{project.projectVersion}</tr>
                                                    <tr>ProjectStatus:{project.projectStatus}</tr>
                                                     <tr>_______________________________</tr>                               
                                                </tr>
                                            ))}

                                            </td>
                                            <td>{clientVisit.clientFeedbacks.map(clientFeedback => (
                                                <tr id="client">
                                                    <tr>FeedBackId:{clientFeedback.feedBackId}</tr>
                                                    <tr>Expectation:{clientFeedback.expectation}</tr>
                                                    <tr>improvement:{clientFeedback.improvement}</tr>
                                                    <tr>_______________________________</tr> 
                                                </tr>
                                            ))}
                                            </td>
                                        </tr>

                                    )
                                }

                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
            </div>

        );
    }
}

export default DisplayVisitsByChapter;