import React, { Component } from 'react';
import {Formik,Form,Field, ErrorMessage} from 'formik';
import ClientDataService from '../Service/ClientDataService';
import Nav1 from '../Nav1';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';

class AddClient extends Component {
    constructor(props) {
        super(props);
        this.state = {
            clientId: '',
            clientCompanyName: '',
            representativeName:'',
            location: '',
            mobileNumber: '',
            emailAddress:'',
            message:''
        }
        this.validateAddClientForm = this.validateAddClientForm.bind(this)  
        this.onSubmit=this.onSubmit.bind(this)   
    }
    onSubmit(client){
        console.log(client)
        ClientDataService.addClient(client).then(response=>{
            this.props.history.push("/upcomingclientvisit")
            console.log(response)
        })
        
    }
    validateAddClientForm(values){
        let errors={}
        if(!values.clientCompanyName){
            errors.clientCompanyName='Enter a Client Company Name'
        }
        if(!values.representativeName){
            errors.representativeName='Enter a Representative Name'
        }
        if(!values.location){
            errors.location='Enter a Location'
        }
        if(!values.mobileNumber){
            errors.mobileNumber='Enter a Mobile Number'
        }
        if(!values.emailAddress){
            errors.emailAddress='Enter Email Address'
        }
        if(values.mobileNumber.length!==10 && values.mobileNumber)
        {
            errors.mobileNumber='Mobile Number should be 10 digit Number'
        }   
        return errors
    }
    render() {
        let{clientId,clientCompanyName,representativeName,location,mobileNumber,emailAddress}=this.state
        return (
            <div>
            <img src={dxc} class="logo"></img>
             <b>DXC Client Visit App</b>
            <Nav1></Nav1>
        <div className="bootstrap-iso">
            <div className="addc">
        <div className='container'>          
            <div className="container col-md-4">
            
            {this.state.message && <div className='alert alert-danger'>{this.state.message}</div>}
                <Formik
                    initialValues={{clientId,clientCompanyName,representativeName,location,mobileNumber,emailAddress}}
                    enableReinitialize={true}
                    onSubmit={this.onSubmit}
                    validateOnChange={true}
                    validateOnBlur={false}
                    validate={this.validateAddClientForm}>
                    <Form>
                    <fieldset className="form-group">
                    <h2> Enter Client Details</h2>  <br></br>
                        {/* <label>Client Id</label>
                        <Field type="text" className="form-control" name="clientId" /><br></br> */}
                        <label>Client Company Name</label>
                        <Field type="text" className="form-control" name="clientCompanyName" /><br></br>
                    <ErrorMessage name="clientCompanyName" component="div" className="alert alert-warning"/>
                        <label>Representative Name</label>
                        <Field type="text" className="form-control" name="representativeName" /> <br></br>       
                    <ErrorMessage name="representativeName" component="div" className="alert alert-warning"/>     
                        <label>Location</label>
                        <Field type="text" className="form-control" name="location" /> <br></br>
                    <ErrorMessage name="location" component="div" className="alert alert-warning"/>           
                        <label>Mobile Number</label>
                        <Field type="text" className="form-control" name="mobileNumber" /> <br></br>        
                    <ErrorMessage name="mobileNumber" component="div" className="alert alert-warning"/>                     
                        <label>Email Address</label>
                        <Field type="email" className="form-control" name="emailAddress" /> <br></br>          
                    <ErrorMessage name="emailAddress" component="div" className="alert alert-warning"/>
                    <button className="btn btn-info" type="submit" >Add</button>
                    </fieldset>
                    </Form> 
                </Formik>
            </div>
        </div>
        </div>
        </div>
        </div>
        );
    }
    }
export default AddClient;