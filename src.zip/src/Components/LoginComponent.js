import React, { Component } from 'react';
import { Redirect } from 'react-router-dom'
// import '../Styles/LoginComponent.css'
import '../App.css'
import UserDataService from '../Service/UserDataService';
import dxc from '../dxc.png';
import '../bootstrap-iso.css'
import { SocialIcon } from 'react-social-icons';
class Login extends Component {
    constructor(props) {
        super(props);
        const token = localStorage.getItem("token")
        let loggedIn = true

        if (token == null) {
            loggedIn = false
        }
        this.state = {
            userName: '',
            password: '',
            errorUserName: '',
            errorPassword: '',
            loggedIn
        }
        this.handlePasswordChange = this.handlePasswordChange.bind(this);
        this.handleUserNameChange = this.handleUserNameChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.dismissError = this.dismissError.bind(this);
    }

    dismissError() {
        this.setState({ errorUserName: '',
    errorPassword: '' });
    }

    handleSubmit(evt) {
        evt.preventDefault();
        // const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);
        if (!this.state.userName) {
            return this.setState({ errorUserName: 'Username is required' });
        }
        if (!this.state.password) {
            return this.setState({ errorPassword: 'Password is required' });
        }
        else{
            UserDataService.isValidUser(this.state.userName,this.state.password).then(response=>{
                console.log(response.status)
                if(response.status===200){
                    console.log("Success")
                    this.props.history.push("/upcomingclientvisit")
                    
                }
                else{
                    console.log("Enter Valid User")
                    this.props.history.push("/")
                }
            })
            localStorage.setItem("token", "tokensample")
        }
        // if( validEmailRegex.test(this.state.userName)){
        //     return this.setState({ errorUserName: 'Username is invalid' });
        // }
        if(this.state.password.length<5){
            return this.setState({errorPassword:'Password must be minimum 6 characters long!'});
        }

        return this.setState({ 
            errorUserName: '',
            errorPassword: '' });
    }
    handleUserNameChange(evt) {
        this.setState({
            userName: evt.target.value,
        });
    };
    handlePasswordChange(evt) {
        this.setState({
            password: evt.target.value,
        });
    }
    render() { 
        
        if (this.state.loggedIn) {
            return <Redirect to="/upcomingclientvisit"></Redirect>
        }
        return (
            <div className="bootstrap-iso">
            <div className="home">
             <img src={dxc} class="logo"></img>
             <b style={{color:"dodgerblue"}}>DXC Client Visit App</b>
             
        <div className='container' >          
            <div className="container col-md-4">
            <br></br>           
                <form onSubmit={this.handleSubmit}>
                    <div className="form-group">
                        <h1>Home Page</h1>
                        <label>User Name</label>
                        <i class="fa fa-user icon"></i>
                        <input type="text" placeholder="Username" className="form-control" name="userName" value={this.state.userName} onChange={this.handleUserNameChange} />
                        <span style={{fontSize:15,color:"red"}} name="error" >
                        {this.state.errorUserName}
                    </span><br></br>
                        <label>Password</label>
                        <i class="fa fa-key icon"></i>
                        <input type="password" placeholder="Password" className="form-control" name="password" value={this.state.password} onChange={this.handlePasswordChange} />
                    <span style={{fontSize:15,color:"red"}} name="error">
                        {this.state.errorPassword}
                    </span><br></br><br></br>
                        <input type="submit" value="Log In" name="submit" className='btn btn-info' onClick={this.dismissError}/>
                    </div>
                </form>
            </div>
        </div>
        <div className="social">
        <SocialIcon url="http://twitter.com/" style={{ height: 40, width: 40 }}/>
        <SocialIcon url="http://linkedin.com" style={{ height: 40, width: 40 }}/>
        <SocialIcon url="http://facebook.com/"style={{ height: 40, width: 40 }}/>
        <SocialIcon url="https://www.dxc.technology/"style={{ height: 40, width: 40 }}/>
        </div>
        </div>
        </div>
        );
    }
}

export default Login;