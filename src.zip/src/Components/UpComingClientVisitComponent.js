import React, { Component } from 'react';
import UpComingClientVisitService from '../Service/UpComingClientVisitService';
import Popup from "reactjs-popup"
// import '../general.css'
import Nav1 from '../Nav1';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';
import {Icon} from '@opuscapita/react-icons'
import ClientVisitDataService from '../Service/ClientVisitDataService';

class ClientVisitPage extends Component {
    constructor(props) {
        super(props); 
        this.state = ({
            clientVisits: [],
            message: ''
        })
        
        this.refreshUpComingClientVisitPage = this.refreshUpComingClientVisitPage.bind(this)

    }
    componentWillMount() {
        this.refreshUpComingClientVisitPage()
    }
    componentDidUpdate(){
        setTimeout(() => this.setState({message:''}), 6000);
      }
    refreshUpComingClientVisitPage() {
        UpComingClientVisitService.getUpComingVisit().then(response => {
            console.log(response.data)
            this.setState({
                clientVisits: response.data
            })
            
        })
    }
    cancelVisitClicked(visitId){
        console.log(visitId)
        ClientVisitDataService.cancelClientVisits(visitId).then(response=>{
            this.setState({
                message: "Visit Cancelled Successfully"
              });
            this.refreshUpComingClientVisitPage()
        })
        
    }
    editButtonclicked(visitId){
        console.log(visitId)
        this.props.history.push(`/reschedule/${visitId}`)
    }
    render() {
        return (
<div>
                
                <img src={dxc} class="logo"></img>
                 <b>DXC Client Visit App</b>
                <Nav1></Nav1>
            <div className="bootstrap-iso">
                <div className="upcoming">
                <div className='container'>
                    <h1><center>Upcoming Client Visits</center></h1>
                    {this.state.message && <div className='alert alert-success'>{this.state.message}</div>}
                    <table className="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Client Company Name</th>
                                <th>Representative Name</th>
                                <th>Date Of Visit</th>
                                <th>Reschedule Visit</th>
                                <th>Cancel Visit</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.clientVisits.map(clientVisit =>
                                    <tr key={clientVisit.visitId}>
                                        <td>{clientVisit.client.clientCompanyName}</td>
                                        <td>{clientVisit.client.representativeName}</td>
                                        <td>{clientVisit.dateOfVisit}</td>
                                        
                                        <td>
                                        <Icon type="indicator" name="edit" onClick={() => this.editButtonclicked(clientVisit.visitId)}/>
                                        </td>
                                        
                                         <td><Popup
                                            trigger={<Icon type="indicator" name="delete" />}
                                            modal
                                            closeOnDocumentClick={true}
                                            >
                                                <div>Are you sure you want to delete the visit?</div><br></br>
                                            <button onClick={() => this.cancelVisitClicked(clientVisit.visitId)}>Yes</button>
                                            {close=>(
                                                <div>
                                                <button onClick={close}>No</button>
                                                </div>
                                            )}
                                            
                                            
                                        </Popup></td>

                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            </div>

        );
    }
}

export default ClientVisitPage;