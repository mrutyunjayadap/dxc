import React, { Component } from 'react';
import { Formik,Form,Field, ErrorMessage } from 'formik';
import ClientDataService from '../Service/ClientDataService';
import ClientVisitDataService from '../Service/ClientVisitDataService';
import Nav1 from '../Nav1';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';

class AddClientVisitComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visitId: '',
            clients:[{clientId: '', clientCompanyName: '',representativeName:'', location: '', mobileNumber: '', emailAddress: '' }],
            dateOfVisit:'',
            message:''
        };
        this.validateAddClientVisitForm=this.validateAddClientVisitForm.bind(this)
        this.refreshClientDetails=this.refreshClientDetails.bind(this)
        this.onSubmit=this.onSubmit.bind(this)
    }
    onSubmit(clientVisit){
        
        console.log(clientVisit.dateOfVisit)
        var myVisit=new Date(clientVisit.dateOfVisit)
        myVisit=myVisit.getDate()+'-'+(myVisit.getMonth()+1)+'-'+myVisit.getFullYear()
        clientVisit.dateOfVisit=myVisit
        console.log(clientVisit.dateOfVisit)
        ClientVisitDataService.addClientVisit(clientVisit).then(response=>{
            this.props.history.push(`/${clientVisit.visitId}/addProjectForVisit`)
        })
    }
    componentWillMount(){
        this.refreshClientDetails()
    }
    refreshClientDetails(){
        ClientDataService.getAllClients().then(response=>{
            console.log(response.data)
            this.setState({
                clients:response.data
            })
        })
    }

    validateAddClientVisitForm(values){
        let errors={}
        if(!values.visitId){
            errors.visitId='Enter a visitId'
        }
        if(!values.clientId){
            errors.clientId='Select a client'
        }
        if(!values.dateOfVisit){
            errors.dateOfVisit='Select a dateOfVisit' 
        }
        return errors
    }
    render() {
        let{visitId,clientId,dateOfVisit}=this.state
        return (
            <div >
                <img src={dxc} class="logo"></img>
                 <b>DXC Client Visit App</b>
                <Nav1></Nav1>
                 <div className="bootstrap-iso">
                     <div className="addcv">
                         <div className='container'>   
                                <div className="container col-md-4">
                                {this.state.message && <div className='alert alert-danger'>{this.state.message}</div>}
                                    <Formik
                                    initialValues={{visitId,clientId,dateOfVisit}}
                                    enableReinitialize={true}
                                    onSubmit={this.onSubmit}
                                    validateOnChange={true}
                                    validateOnBlur={false}
                                    validate={this.validateAddClientVisitForm}
                                    >
                                    <Form>
                                    <fieldset className="form-group">
                                    <h2>Add Client Visit</h2><br></br>
                                            <label>Visit Id</label>
                                            <Field type="text" className="form-control" name="visitId" /><br></br>
                                        <ErrorMessage name="visitId" component="div" className="alert alert-warning"/>
                                            <label>Client Name</label>
                                            <div className="center">
                                            <Field as="select" name="clientId" className="form-control">
                                                <option>Client Company - Representative Name</option>
                                                {
                                                    this.state.clients.map(client=>
                                                    <option value={client.clientId}>{client.clientCompanyName}-{client.representativeName}</option>
                                                        )                             
                                                }
                                                <ErrorMessage name="clientId" component="div" className="alert alert-warning"/>
                                            </Field>
                                            
                                            </div>    <br></br> 
                                        
                                            <label>Date</label>
                                            <Field type="date" className="form-control" name="dateOfVisit" /><br></br>
                                            <ErrorMessage name="dateOfVisit" component="div" className="alert alert-warning"/>
                                 <button type="submit"  name="submit" className='btn btn-info' >Add</button>
                                </fieldset>
                                    </Form>
                                    </Formik>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        );
    }
}

export default AddClientVisitComponent;