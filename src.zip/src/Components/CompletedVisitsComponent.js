import React, { Component } from 'react';
import '../App.css';
import ClientVisitDataService from '../Service/ClientVisitDataService';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';

import Nav1 from '../Nav1';
import FeedbackDataService from '../Service/FeedbackDataService';
class ClientVisitDetails extends Component {
    constructor(props) {
        super(props);
        this.refreshCompletedVisit = this.refreshCompletedVisit.bind(this);
        this.deleteButtonClicked = this.deleteButtonClicked.bind(this);
        this.updateButtonClicked = this.updateButtonClicked.bind(this);

        this.state = ({
            clientVisits: [],
            message: ''
        })
    }

    componentWillMount() {
        this.refreshCompletedVisit();
    }
    componentDidUpdate(){
        setTimeout(() => this.setState({message:''}), 6000);
    }
    refreshCompletedVisit() {

        ClientVisitDataService.viewCompletedVisits().then(
            response => {
                this.setState({
                    clientVisits: response.data
                })

            }

        )
    }

    deleteButtonClicked(visitId) {
        console.log(visitId)
        console.log("delete clicked")
        ClientVisitDataService.deleteClientVisit(visitId).then(response=>{
            this.setState({
                message:  'Visit deleted successfully'
                })
            this.refreshCompletedVisit()
        })

    }
    updateButtonClicked(visitId) {
        this.props.history.push(`/editClientVisitDetails/${visitId}`)
    }

    addFeedbackClicked(visitId)
    {
        
        this.props.history.push(`/addFeedback/${visitId}`);
    }
    deleteFeedbackClicked(visitId, feedBackId)
    {
        FeedbackDataService.deleteFeedback(visitId, feedBackId).then(response => {
          this.setState({
            message: "Feedback Deleted Successfully"
          });
          this.refreshCompletedVisit();
        });
    }
    editFeedbackClicked(visitId, feedBackId)
    {
        this.props.history.push(`/editFeedback/${visitId}/${feedBackId}`);
    }
    render() {
        return (
            <div>
                <img src={dxc} class="logo"></img>
                 <b>DXC Client Visit App</b>
                <Nav1></Nav1>
            <div className="bootstrap-iso">
            <div className="completed">
                <div className="container">
                    
                    <h3>All Completed Visits</h3>
                    {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
                    <div className="container">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Client</th>
                                    <th style={{textAlign:"center"}}>Date of Visit</th>

                                    {/* list of projects */}
                                    <th style={{textAlign:"center"}}>Project To Visit</th> 
                                    {/* list of feedbacks */}
                                    <th>Client Feedback</th> 

                                    <th>Actions</th>
                                    

                                </tr>

                            </thead>
                            <tbody>
                                {
                                    this.state.clientVisits.map(clientVisit =>
                                        <tr key={clientVisit.visitId}>
                                            <td id="client">
                                                <tr>Company Name:{clientVisit.client.clientCompanyName}</tr>
                                                <tr>Representative Name:{clientVisit.client.representativeName}</tr>
                                                <tr>Location:{clientVisit.client.location}</tr>
                                                <tr>Contact No:{clientVisit.client.mobileNumber}</tr>
                                                <tr>Email:{clientVisit.client.emailAddress}</tr>
                                            </td>
                                            <td>{clientVisit.dateOfVisit}</td>

                                            <td>{clientVisit.projectToVisit.map(project => (
                                                <tr id="project">
                                                    <tr>Project Name:{project.projectName}</tr>
                                                    <tr>Chapter Name:{project.chapterToWhichBelongs}</tr>
                                                    <tr>Project Manager:{project.projectManager}</tr>
                                                    <tr>Project Version:{project.projectVersion}</tr>
                                                    <tr>Project Status:{project.projectStatus}</tr>
                                                     <tr>_______________________________</tr>                               
                                                </tr>
                                            ))}

                                            </td>
                                            <td>{clientVisit.clientFeedbacks.map(clientFeedback => (
                                                <tr key={clientFeedback.feedBackId} id="client">
                                                    <tr>Expectation:{clientFeedback.expectation}</tr>
                                                    <tr>Improvement:{clientFeedback.improvement}</tr>
                                                    <tr>_______________________________</tr> 
                                                    <td>
                                                        <button
                                                            className="btn btn-outline-warning btn-sm"
                                                            onClick={() =>
                                                                this.editFeedbackClicked(
                                                                    clientVisit.visitId,
                                                                    clientFeedback.feedBackId
                                                                )
                                                            }
                                                        >
                                                            Edit
                                                        </button>
                                                   
                                                        <button
                                                            className="btn btn-outline-danger btn-sm"
                                                            onClick={() =>
                                                                this.deleteFeedbackClicked(
                                                                    clientVisit.visitId,
                                                                    clientFeedback.feedBackId
                                                                )
                                                            }
                                                        >
                                                            Delete
                                                        </button>
                                                    </td>
                                                </tr>
                                            ))}
                                                <tr>
                                                    <button
                                                        className="btn btn-outline-info btn-sm"
                                                        onClick={() =>
                                                            this.addFeedbackClicked(clientVisit.visitId)
                                                        }
                                                    >
                                                        Add New feedback
                                                    </button>
                                                </tr>
                                            </td>
                                            <div class="button">
                                            <td >
                                            {/* <button className="btn btn-outline-warning" onClick={() => this.updateButtonClicked(clientVisit.visitId)}>Edit</button> */}
                                            <button className="btn btn-outline-danger" onClick={() => this.deleteButtonClicked(clientVisit.visitId)}>Delete</button>
                                            </td>
                                            </div>
                                        </tr>

                                    )
                                }

                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
            </div>
            </div>

        );
    }
}

export default ClientVisitDetails;