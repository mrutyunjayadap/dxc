import React, { Component } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import ProjectDataService from '../Service/ProjectDataService';
import Nav1 from '../Nav1';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';

class AddProject extends Component {
    constructor(props) {
        super(props);
        this.state = {
            projectId: '',
            projectName: '',
            chapterToWhichBelongs: '',
            projectManager: '',
            projectVersion: '',
            projectStatus: '',
            message: ''


        }
        this.validateAddProjectForm = this.validateAddProjectForm.bind(this)
        this.onSubmit=this.onSubmit.bind(this)

    }
    onSubmit(project){
        console.log("button clicked")
        console.log(project)
        ProjectDataService.addProject(project).then(response=>{
            this.props.history.push("/upcomingclientvisit");
            console.log(response);
        })
    }

    validateAddProjectForm(values) {
        let errors = {}
        if (!values.projectName) {
            errors.projectName = 'Enter a Project Name'
        }
        if (!values.chapterToWhichBelongs) {
            errors.chapterToWhichBelongs = 'Enter Chapter To Which it Belongs'
        }
        if (!values.projectManager) {
            errors.projectManager = 'Enter a Project Manager'
        }
        if (!values.projectVersion) {
            errors.projectVersion = 'Enter a Project Version'
        }
        if (!values.projectStatus) {
            errors.projectStatus = 'Enter a Project Status'
        }
        // else if (!values.projectId) {
        //     errors.projectId = 'Enter a Project Id'
        // }


        return errors
    }
   

    render() {
        let { projectId, projectName, chapterToWhichBelongs, projectManager, projectStatus, projectVersion } = this.state

        return (
            <div>
            <img src={dxc} class="logo"></img>
             <b>DXC Client Visit App</b>
            <Nav1></Nav1>
        <div className="bootstrap-iso">
        <div className="addproj">
        <div className='container'>


            <div className="container col-md-4">
                
                {this.state.message && <div className='alert alert-danger'>{this.state.message}</div>}

                <Formik
                    initialValues={{ projectId, projectName, chapterToWhichBelongs, projectManager, projectStatus, projectVersion }}
                    enableReinitialize={true}
                    onSubmit={this.onSubmit}
                    validateOnChange={true}
                    validateOnBlur={false}
                    validate={this.validateAddProjectForm}>

                <Form>
                        <fieldset className="form-group">
                        <h2> Enter Project details</h2>
                            {/* <label>Project Id</label>
                            <Field type="text" className="form-control" name="projectId" />
                            <ErrorMessage name="projectId" component="div" className="alert alert-warning" /><br></br> */}


                            <label>Project Name</label>
                            <Field type="text" className="form-control" name="projectName" />
                            <ErrorMessage name="projectName" component="div" className="alert alert-warning" /><br></br>



                            <label>Chapter Name</label>
                            <Field type="text" className="form-control" name="chapterToWhichBelongs" />
                            <ErrorMessage name="chapterToWhichBelongs" component="div" className="alert alert-warning" /><br></br>



                            <label>Project Manager</label>
                            <Field type="text" className="form-control" name="projectManager" />
                            <ErrorMessage name="projectStatus" component="div" className="alert alert-warning" /><br></br>



                            <label>Project Version</label>
                            <Field type="text" className="form-control" name="projectVersion" />
                            <ErrorMessage name="projectVersion" component="div" className="alert alert-warning" /><br></br>



                            <label>Project Status</label>
                            <Field type="text" className="form-control" name="projectStatus" />
                            <ErrorMessage name="projectManager" component="div" className="alert alert-warning" /><br></br>


                        <button className="btn btn-info" type="submit" >Add</button>
                        </fieldset>

                    </Form>
                </Formik>
            </div>
        </div>
        </div>
        </div>
        </div>
        );
    }
}

export default AddProject;