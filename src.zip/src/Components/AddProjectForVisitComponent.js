import React, { Component } from 'react';
import '../Styles/ProjectDetailsComponent.css'
import ProjectDataService from '../Service/ProjectDataService';
import ClientVisitDataService from '../Service/ClientVisitDataService';
import Nav1 from '../Nav1';
import dxc from '../dxc.png';

class AddProjectForVisit extends Component {
    constructor(props) {
        super(props) //since we are extending class Table so we have to use super in order to override Component class constructor
        this.state = { //state is by default an object
           projects: [],
           visitId:this.props.match.params.visitId,
           message:''
        }
        this.refreshProjectDetailsPage=this.refreshProjectDetailsPage.bind(this)
        this.addProjectClicked=this.addProjectClicked.bind(this)
        this.homePage=this.homePage.bind(this)
     }
         componentWillMount() {
            this.refreshProjectDetailsPage()
      }
      componentDidUpdate(){
        setTimeout(() => this.setState({message:''}), 6000);
    }
      refreshProjectDetailsPage() {
         ProjectDataService.viewProjectDetails().then(response=>{
            console.log(response.data)
            this.setState({
               projects: response.data
            })
         })
      }
      addProjectClicked(projectIdToAdd){
        ClientVisitDataService.addProjectForVisit(this.state.visitId,projectIdToAdd).then(response=>{
            this.setState({
                message: "Project added Successfully"
              });
        })
 }
        homePage(){
            this.props.history.push("/upcomingclientvisit")
        }
    render() {
      return (
        <div>
        <img src={dxc} class="logo"></img>
           <b>DXC Client Visit App</b>
        <Nav1></Nav1>
        <div className="bootstrap-iso">
            <div className="addpforv">
        <div className='container'>
            <h1><center>Project Details Page</center></h1>
            {this.state.message && <div className='alert alert-success'>{this.state.message}</div>}
            <table className="table table-striped table-hover">
                <thead>
                    <tr>
                        {/* <th>Project Id</th> */}
                        <th>Project Name</th>
                        <th>Chapter Name</th>
                        <th>Project Manager</th>
                        <th>Project Version</th>
                        <th>Project Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        this.state.projects.map(project =>
                            <tr key={project.projectId}>
                                {/* <td>{project.projectId}</td> */}
                                <td>{project.projectName}</td>
                                <td>{project.chapterToWhichBelongs}</td>
                                <td>{project.projectManager}</td>
                                <td>{project.projectVersion}</td>
                                <td>{project.projectStatus}</td>
                                <div id="container" class="col-sm-12">
                                    <button className="btn btn-outline-warning btn-sm"  onClick={()=>this.addProjectClicked(project.projectId)}>Add</button>
                                    
                                 </div>
                            </tr>
                        )
                    }
                </tbody>
            </table>
            <div className="div1">
            <button className="b" onClick={()=>this.homePage()}>Done</button>
            </div>
        </div>
    </div>
    </div>
    </div>
      );
  }
}

export default AddProjectForVisit;