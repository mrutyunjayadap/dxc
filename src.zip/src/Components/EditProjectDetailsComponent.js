import React, { Component } from 'react';
import ProjectDataService from '../Service/ProjectDataService';
import {Formik,Form,Field, ErrorMessage} from 'formik';
import dxc from '../dxc.png';
import Nav1 from '../Nav1';
import '../bootstrap-iso.css'

class EditProjectDetails extends Component {
    constructor(props) {
        super(props);
        this.state=({
            projectId:this.props.match.params.projectId,
            projectName: '',
            chapterToWhichBelongs:'',
            projectManager:'',
            projectVersion: '',
            projectStatus:'',
        })
this.validateEditProjectForm=this.validateEditProjectForm.bind(this);
this.onSubmit=this.onSubmit.bind(this);

    }
    componentWillMount()
    {
        ProjectDataService.getProjectById(this.state.projectId).then(response =>{
            this.setState({
                projectName: response.data.projectName,
                chapterToWhichBelongs:response.data.chapterToWhichBelongs,
                projectManager:response.data.projectManager,
                projectVersion: response.data.projectVersion,
                projectStatus:response.data.projectStatus
            })
        console.log(this.state.projectName)
        })
    }
  
    onSubmit(project){
        ProjectDataService.editProjectDetails(project).then(
            ()=> this.props.history.push(`/viewProjectDetails`)
        )
    }

    validateEditProjectForm(values){
        let errors = {}
        if (!values.projectName) {
            errors.projectName = 'Enter a Project Name'
        }
        if (!values.chapterToWhichBelongs) {
            errors.chapterToWhichBelongs = 'Enter Chapter To Which it Belongs'
        }
        if (!values.projectManager) {
            errors.projectManager = 'Enter a Project Manager'
        }
        if (!values.projectVersion) {
            errors.projectVersion = 'Enter a Project Version'
        }
        if (!values.projectStatus) {
            errors.projectStatus = 'Enter a Project Status'
        }
        return errors
    }
    render() {
        let{projectId,projectName,chapterToWhichBelongs,projectManager,projectVersion,projectStatus}=this.state

            return (
                <div>
                    
                <img src={dxc} class="logo"></img>
                 <b>DXC Client Visit App</b>
                <Nav1></Nav1>
                <div className="bootstrap-iso">
                    <div className="editproj">
                <div className='container'>
                    <br></br>
                    <div className="container col-md-4">
                    
                    <Formik
                        initialValues={{projectId,projectName,chapterToWhichBelongs,projectManager,projectVersion,projectStatus}}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={true}
                        validateOnBlur={false}
                        validate={this.validateEditProjectForm}
                        >
                        <Form>
                            <fieldset className="form-group">
                                <label>Project Name</label>
                                <Field className="form-control" type="text" name="projectName"/>
                                <ErrorMessage name="projectName" component="div" className="alert alert-warning"/><br></br>

                            
                                <label>Chapter Name</label>
                                <Field className="form-control" type="text" name="chapterToWhichBelongs"/>
                                <ErrorMessage name="chapterToWhichBelongs" component="div" className="alert alert-warning"/><br></br>

                            
                                <label>Project Manager</label>
                                <Field className="form-control" type="text" name="projectManager"/>
                                <ErrorMessage name="projectManager" component="div" className="alert alert-warning"/><br></br>

                           
                                <label>Project Version</label>
                                <Field className="form-control" type="text" name="projectVersion"/>
                                <ErrorMessage name="projectVersion" component="div" className="alert alert-warning"/><br></br>

                            
                                <label>Project Status</label>
                                <Field className="form-control" type="text" name="projectStatus"/>
                                <ErrorMessage name="projectStatus" component="div" className="alert alert-warning"/><br></br>

                            
                            <button className="btn btn-warning" type="submit" >Update</button>
                            </fieldset>
                        </Form>
                    </Formik>
                    </div> 
                </div>
                </div>
             </div>
             </div>
            );
         
        
    }
    
}

export default EditProjectDetails;