import React, { Component } from 'react';
import '../App.css';
import ClientVisitDataService from '../Service/ClientVisitDataService';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';
import {Icon} from '@opuscapita/react-icons'

import "react-datepicker/dist/react-datepicker.css";
import Nav1 from '../Nav1';

class DisplayVisitsByDate extends Component {
    constructor(props) {
        super(props);

        this.state = ({
            clientVisits: [],
            endDate:this.props.match.params.end,
            startDate:this.props.match.params.start
            
        })
        this.backClicked=this.backClicked.bind(this)
    }
    backClicked(){
        this.props.history.push(`/viewClientVisitDetails`)
    }

    componentWillMount() {
        console.log(this.state.startDate,this.state.endDate)
        ClientVisitDataService.searchByDate(this.state.startDate,this.state.endDate).then(
            response => {
                console.log(response)
                this.setState({
                    clientVisits: response.data
                })

            }

        )
    }

    render() {
        return (
            <div>
            <img src={dxc} class="logo"></img>
             <b>DXC Client Visit App</b>
            <Nav1></Nav1>
        <div className="bootstrap-iso">
        <div className="visitdate">
            <div className="container">
                
                <h2>Visits By Date</h2>
                {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
                <div className="container">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Visit Id</th>
                                <th>Date of Visit</th>
                                <th style={{textAlign:"left"}}>Client</th>
                                {/* list of projects */}
                                <th style={{textAlign:"left"}}>Project To Visit</th> 
                                {/* list of feedbacks */}
                                <th  style={{textAlign:"left"}}>Client Feedback</th> 
                                <Icon type="indicator" name="arrowLeft" onClick={() =>this.backClicked()}></Icon>
                                

                            </tr>

                        </thead>
                        <tbody>
                            {
                                this.state.clientVisits.map(clientVisit =>
                                    <tr key={clientVisit.visitId}>
                                        <td>{clientVisit.visitId}</td>
                                        <td>{clientVisit.dateOfVisit}</td>
                                        <td id="client"><tr>Client Id:{clientVisit.client.clientId}</tr>
                                            <tr>Company Name:{clientVisit.client.clientCompanyName}</tr>
                                            <tr>Representative Name:{clientVisit.client.representativeName}</tr>
                                            <tr>Location:{clientVisit.client.location}</tr>
                                            <tr>Contact No:{clientVisit.client.mobileNumber}</tr>
                                            <tr>Email:{clientVisit.client.emailAddress}</tr>

                                        </td>
                                        <td>{clientVisit.projectToVisit.map(project => (
                                            <tr id="project">
                                                <tr>Project Name:{project.projectName}</tr>
                                                <tr>Chapter Name:{project.chapterToWhichBelongs}</tr>
                                                <tr>Project Manager:{project.projectManager}</tr>
                                                <tr>Project Version:{project.projectVersion}</tr>
                                                <tr>Project Status:{project.projectStatus}</tr>
                                                 <tr>_______________________________</tr>                               
                                            </tr>
                                        ))}

                                        </td>
                                        <td>{clientVisit.clientFeedbacks.map(clientFeedback => (
                                            <tr id="client">
                                                <tr>FeedBackId:{clientFeedback.feedBackId}</tr>
                                                <tr>Expectation:{clientFeedback.expectation}</tr>
                                                <tr>improvement:{clientFeedback.improvement}</tr>
                                                <tr>_______________________________</tr> 
                                            </tr>
                                        ))}
                                        </td>
                                    </tr>

                                )
                            }

                        </tbody>

                    </table>
                </div>
            </div>
        </div>
        </div>
        </div>

        );
    }
}

export default DisplayVisitsByDate;