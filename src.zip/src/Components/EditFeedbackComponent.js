import React, { Component } from 'react';
import {Formik,Form,Field, ErrorMessage} from 'formik';
import FeedbackDataService from '../Service/FeedbackDataService';
import Nav1 from '../Nav1';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';

class EditFeedback extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visitId:this.props.match.params.visitId,
            feedBackId:this.props.match.params.feedBackId ,
            expectation: '',
            improvement:'',
            message:''
        }
        this.validateEditFeedbackForm = this.validateEditFeedbackForm.bind(this)  
        this.onSubmit=this.onSubmit.bind(this)   
    }
    componentWillMount(){
        FeedbackDataService.getFeedbackById(this.state.visitId,this.state.feedBackId).then(response=>{
            this.setState({
                expectation:response.data.expectation,
                improvement:response.data.improvement
            })
            console.log(this.state.feedBackId)
        }
        )
    }
    onSubmit(feedback){
        console.log(this.state.visitId)
        FeedbackDataService.addFeedback(this.state.visitId,feedback).then(response=>{
            this.props.history.push("/completedVisits")
        })
        
    }
    validateEditFeedbackForm(values){
        let errors={}
        if(!values.expectation){
            errors.expectation='Enter Expectations '
        }
        if(!values.improvement){
            errors.improvement='Enter Improvements'
        }
        return errors
    }
    render() {
        let{feedBackId,expectation,improvement}=this.state
        return (
            <div>
            <img src={dxc} class="logo"></img>
             <b>DXC Client Visit App</b>
            <Nav1></Nav1>
        <div className="bootstrap-iso">
            <div className="editfeed">
        <div className='container'>          
            <div className="container col-md-4">
            {this.state.message && <div className='alert alert-danger'>{this.state.message}</div>}
                <Formik
                    initialValues={{feedBackId,expectation,improvement}}
                    enableReinitialize={true}
                    onSubmit={this.onSubmit}
                    validateOnChange={true}
                    validateOnBlur={false}
                    validate={this.validateEditFeedbackForm}>
                    <Form>
                    <fieldset className="form-group">
                    <h2> Edit FeedBack </h2>  <br></br>
                        <label>Expectation</label>
                        <Field type="text" className="form-control" name="expectation" />
                    <ErrorMessage name="expectation" component="div" className="alert alert-warning"/><br></br>
                        <label>Improvement</label>
                        <Field type="text" className="form-control" name="improvement" />         
                    <ErrorMessage name="improvement" component="div" className="alert alert-warning"/><br></br>

                    <button className="btn btn-warning" type="submit" >Update</button>
                    </fieldset>

                    </Form> 
                </Formik>
            </div>
        </div>
        </div>
        </div>
        </div>
        );
    }
    }
export default EditFeedback;