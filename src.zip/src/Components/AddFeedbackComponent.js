import React, { Component } from 'react';
import {Formik,Form,Field, ErrorMessage} from 'formik';
import FeedbackDataService from '../Service/FeedbackDataService';
import Nav1 from '../Nav1';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';

class AddFeedback extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visitId:this.props.match.params.visitId,
            feedBackId: '',
            expectation: '',
            improvement:'',
            message:''
        }
        this.validateAddClientForm = this.validateAddClientForm.bind(this)  
        this.onSubmit=this.onSubmit.bind(this)   
    }
    onSubmit(feedback){
        console.log(this.state.visitId)
        FeedbackDataService.addFeedback(this.state.visitId,feedback).then(response=>{
            this.props.history.push("/completedVisits")
        })
        
    }
    validateAddClientForm(values){
        let errors={}
        if(!values.feedBackId){
            errors.feedBackId='Enter feedBackId '
        }
        if(!values.expectation){
            errors.expectation='Enter Expectations '
        }
        if(!values.improvement){
            errors.improvement='Enter Improvements'
        }
        return errors
    }
    render() {
        let{feedBackId,expectation,improvement}=this.state
        return (
            <div>
                <img src={dxc} class="logo"></img>
                 <b>DXC Client Visit App</b>
                <Nav1></Nav1>
            <div className="bootstrap-iso">
                <div className="feedback">
            <div className='container'>          
                <div className="container col-md-4">
                
                {this.state.message && <div className='alert alert-danger'>{this.state.message}</div>}
                    <Formik
                        initialValues={{feedBackId,expectation,improvement}}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={true}
                        validateOnBlur={false}
                        validate={this.validateAddClientForm}>
                        <Form>
                        <fieldset className="form-group">
                        <h2> Enter FeedBack </h2>  <br></br>
                        <label>FeedBack Id</label>
                            <Field type="text" className="form-control" name="feedBackId" />
                        
                        <ErrorMessage name="feedBackId" component="div" className="alert alert-warning"/><br></br>

                            <label>Expectation</label>
                            <Field type="text" className="form-control" name="expectation" />
                        
                        <ErrorMessage name="expectation" component="div" className="alert alert-warning"/><br></br>
                        
                            <label>Improvement</label>
                            <Field type="text" className="form-control" name="improvement" />         
                        <ErrorMessage name="improvement" component="div" className="alert alert-warning"/><br></br>

                        <button className="btn btn-info" type="submit" >Add</button>
                        </fieldset>

                        </Form> 
                    </Formik>
                </div>
            </div>
            </div>
            </div>
            </div>
        );
    }
    }
export default AddFeedback;