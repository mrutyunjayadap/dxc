import React, { Component } from 'react';
import {Formik,Form,Field, ErrorMessage} from 'formik';
import ClientDataService from '../Service/ClientDataService';
import dxc from '../dxc.png';
import Nav1 from '../Nav1';
import '../bootstrap-iso.css'

class EditClientDetails extends Component {
    constructor(props) {
        super(props);
        this.state=({
            clientId:this.props.match.params.clientId,
            clientCompanyName: '',
            representativeName:'',
            location: '',
            emailAddress:'',
        })
this.validateEditclientForm=this.validateEditclientForm.bind(this);
this.onSubmit=this.onSubmit.bind(this);

    }
    componentWillMount()
    {
        ClientDataService.getClientById(this.state.clientId).then(response =>{
            this.setState({
                clientCompanyName:response.data.clientCompanyName,
                representativeName: response.data.representativeName,
                location:response.data.location,
                emailAddress:response.data.emailAddress
            })
        console.log(this.state.clientCompanyName)
        })
    }
  
    onSubmit(client){
        ClientDataService.editClientDetails(client).then(
            ()=> this.props.history.push(`/viewClientDetails`)
        )
    }

    validateEditclientForm(values){
        let errors = {}
        // if (!values.clientId) {
        //     errors.clientId = 'Enter a Client Id'
        // }
        // else 
        if (!values.clientCompanyName) {
            errors.clientCompanyName = 'Enter a Client Company Name'
        }
        if (!values.representativeName) {
            errors.representativeName = 'Enter a Representative Name'
        }
        if (!values.location) {
            errors.location = 'Enter a Location'
        }
        if (!values.emailAddress) {
            errors.emailAddress = 'Enter Email Address'
        }
        return errors
    }
    render() {
        let{clientId,clientCompanyName,representativeName,location,emailAddress}=this.state

            return (
                <div>
                
                <img src={dxc} class="logo"></img>
                 <b>DXC Client Visit App</b>
                <Nav1></Nav1>
                <div className="bootstrap-iso">
                    <div className="editcl">
                <div className='container'>
                    <br></br>
                    <div className="container col-md-4">
                    
                    <Formik
                        initialValues={{clientId,clientCompanyName,representativeName,location,emailAddress}}
                        enableReinitialize={true}
                        onSubmit={this.onSubmit}
                        validateOnChange={true}
                        validateOnBlur={false}
                        validate={this.validateEditclientForm}
                        >
                        <Form>

                            <fieldset className="form-group">
                                <label>Client Company Name</label>
                                <Field className="form-control" type="text" name="clientCompanyName"/>
                                <ErrorMessage name="clientCompanyName" component="div" className="alert alert-warning"/><br></br>

                                <label>Representative Name</label>
                                <Field className="form-control" type="text" name="representativeName"/>
                                <ErrorMessage name="representativeName" component="div" className="alert alert-warning"/><br></br>

                                <label>Location</label>
                                <Field className="form-control" type="text" name="location"/>
                                <ErrorMessage name="location" component="div" className="alert alert-warning"/><br></br>

                                <label>Email Address</label>
                                <Field className="form-control" type="email" name="emailAddress"/>
                                <ErrorMessage name="emailAddress" component="div" className="alert alert-warning"/><br></br>

                            
                            <button className="btn btn-warning" type="submit" >Update</button>
                            </fieldset>
                        </Form>
                    </Formik>
                    </div> 
                    </div>
                </div>
             </div>
             </div>
            );
         
        
    }
    
}

export default EditClientDetails;