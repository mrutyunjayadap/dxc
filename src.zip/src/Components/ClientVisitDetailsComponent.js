import React, { Component } from 'react';
import '../App.css';
import ClientVisitDataService from '../Service/ClientVisitDataService';
import '../bootstrap-iso.css'
import dxc from '../dxc.png';
import {Icon} from '@opuscapita/react-icons'
import {Formik,Form} from 'formik'
import DatePicker from "react-datepicker";
 
import "react-datepicker/dist/react-datepicker.css";

import NavSearchBar from './NavSearchBar';
class ClientVisitDetails extends Component {
    constructor(props) {
        super(props);
        this.refreshClientVisit = this.refreshClientVisit.bind(this);
        this.deleteButtonClicked = this.deleteButtonClicked.bind(this);
        this.updateButtonClicked = this.updateButtonClicked.bind(this);
        this.state = ({
            clientVisits: [],
            startDate:new Date(),
            endDate:new Date()
        })
        this.handleChange=this.handleChange.bind(this)
        this.searchByChapter=this.searchByChapter.bind(this)
        this.onSubmit=this.onSubmit.bind(this)
        this.handleStartDateChange=this.handleStartDateChange.bind(this)
        this.handleEndDateChange=this.handleEndDateChange.bind(this)
    }
    handleChange(evt){
        this.setState({
          chapterName: evt.target.value,
    });
    
    }
    searchByChapter(){
        console.log(this.state.chapterName)
        //this.props.history.push(`/searchByChapter/${this.state.chapterName}`)
        ClientVisitDataService.searchByChapter(this.state.chapterName).then(
            response => {
                console.log(response)
                this.setState({
                    clientVisits: response.data
                })
    })

    }

    handleStartDateChange= date => {
        this.setState({
            startDate: date
          });

    }
    handleEndDateChange= date => {
        this.setState({
            endDate: date
          });

    }
    onSubmit(){

        this.state.startDate=this.state.startDate.getDate()+'-'+(this.state.startDate.getMonth()+1)+'-'+this.state.startDate.getFullYear()
        console.log(this.state.startDate)
        this.state.endDate=this.state.endDate.getDate()+'-'+(this.state.endDate.getMonth()+1)+'-'+this.state.endDate.getFullYear()
        console.log(this.state.endDate)
        this.props.history.push(`/searchByDate/${this.state.startDate}/${this.state.endDate}`)

    }


    componentWillMount() {
        this.refreshClientVisit();
    }
    componentDidUpdate(){
        setTimeout(() => this.setState({message:''}), 6000);
    }
    refreshClientVisit() {

        ClientVisitDataService.getClientVisits().then(
            response => {
                console.log(response)
                this.setState({
                    clientVisits: response.data
                })

            }

        )
    }
    deleteButtonClicked(visitId) {
        ClientVisitDataService.deleteClientVisit(visitId).then(response=>{
            this.setState({
                message:  'Visit deleted successfully'
                })
            this.refreshClientVisit()
        })

    }
    updateButtonClicked(visitId) {
        this.props.history.push(`/editClientVisitDetails/${visitId}`)
    }
    render() {
        return (
            <div>
                <img src={dxc} class="logo"></img>
                 <b>DXC Client Visit App</b>
                <NavSearchBar></NavSearchBar>
                <div className="container">
                    <span class="topnav">
                        <span class="search-container">
                            <tr>
                                <td>
                                    <input type="text" placeholder="Search by chapter.."  name="chapterName" value={this.state.chapterName} onChange={this.handleChange}/>
                                </td>
                                <td>
                                    <Icon type="indicator" name="search" onClick={() => this.searchByChapter()}></Icon>
                                </td>
                            </tr>
                        </span>
                    </span>
                    <span class="dater">
                        <Formik>
                            <Form >
                                <table>
                                    <tr>
                                        <td><strong>Start :</strong></td> 
                                        <td>
                                        <DatePicker
                                            dateFormat="dd/MM/yyyy"
                                            name="startDate"
                                            selected={this.state.startDate}
                                            onSelect={this.handleStartDateChange}
                                        />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>End :</strong></td> 
                                        <td>
                                        <DatePicker
                                            dateFormat="dd/MM/yyyy"
                                            name="endDate"
                                            selected={this.state.endDate}
                                            onSelect={this.handleEndDateChange}
                                        />
                                        </td>
                                        <td><Icon type="indicator" name="search"  onClick={() => this.onSubmit()}></Icon></td>
                                    </tr>
                                </table>
                                
                            </Form>
                        </Formik>
                    </span>
                </div>
            <div className="bootstrap-iso">
            <div className="clientvdet">
                <div className="container">
                    
                    <h1>All Client Visits</h1>
                        {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
                        <div className="container">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th>Client</th>
                                        <th style={{textAlign:"center"}}>Date Of Visit</th>

                                        {/* list of projects */}
                                        <th style={{textAlign:"center"}}>Project To Visit</th> 
                                        {/* list of feedbacks */}
                                        <th>Client Feedback</th> 

                                        <th>Actions</th>
                                        

                                    </tr>

                                </thead>
                                <tbody>
                                    {
                                        this.state.clientVisits.map(clientVisit =>
                                            <tr key={clientVisit.visitId}>
                                                <td id="client">
                                                    <tr>Company Name:{clientVisit.client.clientCompanyName}</tr>
                                                    <tr>Representative Name:{clientVisit.client.representativeName}</tr>
                                                    <tr>Location:{clientVisit.client.location}</tr>
                                                    <tr>Contact No:{clientVisit.client.mobileNumber}</tr>
                                                    <tr>Email:{clientVisit.client.emailAddress}</tr>

                                                </td>
                                                <td>{clientVisit.dateOfVisit}</td>

                                                <td>{clientVisit.projectToVisit.map(project => (
                                                    <tr id="project">
                                                        <tr>Project Name:{project.projectName}</tr>
                                                        <tr>Chapter Name:{project.chapterToWhichBelongs}</tr>
                                                        <tr>Project Manager:{project.projectManager}</tr>
                                                        <tr>Project Version:{project.projectVersion}</tr>
                                                        <tr>Project Status:{project.projectStatus}</tr>
                                                        <tr>_______________________________</tr>                               
                                                    </tr>
                                                ))}

                                                </td>
                                                <td>{clientVisit.clientFeedbacks.map(clientFeedback => (
                                                    <tr id="client">
                                                        <tr>Expectation:{clientFeedback.expectation}</tr>
                                                        <tr>improvement:{clientFeedback.improvement}</tr>
                                                        <tr>_______________________________</tr> 
                                                    </tr>
                                                ))}
                                                </td>
                                                <div class="button">
                                                <td >
                                                {/* <button className="btn btn-outline-warning" onClick={() => this.updateButtonClicked(clientVisit.visitId)}>Edit</button> */}
                                                <button className="btn btn-outline-danger" onClick={() => this.deleteButtonClicked(clientVisit.visitId)}>Delete</button>
                                                </td>
                                                </div>
                                            </tr>

                                        )
                                    }

                                </tbody>

                            </table>
                        </div>
                     </div>
                </div>
                </div>
            </div>
        );
    }
}

export default ClientVisitDetails;