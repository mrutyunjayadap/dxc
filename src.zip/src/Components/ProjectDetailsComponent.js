import React, { Component } from 'react';
import '../Styles/ProjectDetailsComponent.css'
import ProjectDataService from '../Service/ProjectDataService';
import '../bootstrap-iso.css'
import Nav1 from '../Nav1';
import dxc from '../dxc.png';

class ProjectDetails extends Component {
    constructor(props) {
        super(props) //since we are extending class Table so we have to use super in order to override Component class constructor
        this.state = { //state is by default an object
           projects: [],
           message:''
        }
        this.refreshProjectDetailsPage=this.refreshProjectDetailsPage.bind(this)
        this.deleteProjectClicked=this.deleteProjectClicked.bind(this)
        this.editProjectClicked=this.editProjectClicked.bind(this)
     }
         componentWillMount() {
            this.refreshProjectDetailsPage()
      }
      componentDidUpdate(){
        setTimeout(() => this.setState({message:''}), 6000);
      }
      refreshProjectDetailsPage() {
         ProjectDataService.viewProjectDetails().then(response=>{
            console.log(response.data)
            this.setState({
               projects: response.data
            })
         })
      }
      deleteProjectClicked(projectIdTodelete){
         ProjectDataService.deleteProjectDetails(projectIdTodelete).then(response=>{
            this.setState({
                message: "Project Deleted Successfully"
              });
            this.refreshProjectDetailsPage()
         })
      }
         editProjectClicked(projectIdToUpdate){
            this.props.history.push(`/editProjectDetails/${projectIdToUpdate}`)
      }
    render() {
      return (
        <div>
        <img src={dxc} class="logo"></img>
           <b>DXC Client Visit App</b>
        <Nav1></Nav1>
    <div className="bootstrap-iso">
        <div className="projd">
        <div className='container'>
            <h1><center>Project Details Page</center></h1>
            {this.state.message && <div className='alert alert-success'>{this.state.message}</div>}
            <table className="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Project Name</th>
                        <th>Chapter Name</th>
                        <th>Project Manager</th>
                        <th>Project Version</th>
                        <th>Project Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        this.state.projects.map(project =>
                            <tr key={project.projectId}>
                                <td>{project.projectName}</td>
                                <td>{project.chapterToWhichBelongs}</td>
                                <td>{project.projectManager}</td>
                                <td>{project.projectVersion}</td>
                                <td>{project.projectStatus}</td>
                                <div class="button">
                                    <button className="btn btn-outline-warning "  onClick={()=>this.editProjectClicked(project.projectId)}>Edit</button>
                                    <button className="btn btn-outline-danger " onClick={()=>this.deleteProjectClicked(project.projectId)}>Delete</button>
                                 </div>
                            </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
    </div>
    </div>
    </div>
      );
  }
}

export default ProjectDetails;