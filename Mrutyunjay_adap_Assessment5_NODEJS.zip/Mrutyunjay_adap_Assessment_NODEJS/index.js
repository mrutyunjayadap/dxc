var fs = require('fs');
var express = require('express');
var app=express()

app.set("view engine","ejs")

var text=fs.readFileSync("./resources/about.txt")
app.get("/",function(req,res){
  res.render("about",{text:text})
})
app.listen(5000)