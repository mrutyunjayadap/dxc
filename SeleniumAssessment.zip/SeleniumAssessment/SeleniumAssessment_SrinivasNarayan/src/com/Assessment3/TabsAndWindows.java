package com.Assessment3;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TabsAndWindows {
	public WebDriver driver;
	public String Browser = "chrome";

	@Test
	public void testcase1() {
		SoftAssert st = new SoftAssert();
		if (Browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver = new ChromeDriver(); // OpenBrowser
		} else if (Browser.equalsIgnoreCase("mozilla")) {
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			driver = new FirefoxDriver();
		} else if (Browser.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		driver.get("https://www.msn.com/en-in/"); // openUrl
													
		driver.manage().window().maximize(); // maximize browser
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);// implicit
																		// wait
		// click to onenote
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();

		Set<String> allIds = driver.getWindowHandles();
		Iterator<String> it = allIds.iterator();
		String mainId = it.next();
		String tab1 = it.next();

		// TabWindow
		driver.switchTo().window(tab1);
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("987654321");

		// close tab window
		driver.close();

		// switch driver ref to main window
		driver.switchTo().window(mainId);

		// click on skype in the main page
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		
		driver.quit();
	}
}
