package com.dxc.DAO;

import java.util.List;

import com.dxc.model.Doctor;

public interface HospitalDAO {
	public List<Doctor> getAllDoctor();
	public void addDoctor(Doctor doctor);
	public void deleteDoctor(int docId);
	public void updateDoctor(Doctor doctor);
	public Doctor getDoctor(String doctorName);

}
