package com.dxc.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.model.Doctor;

import com.dxc.util.HibernateUtil;

public class HospitalDAOImpl implements HospitalDAO {

	SessionFactory sf=HibernateUtil.getSessionFactory();
	public void addDoctor(Doctor doctor) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println(doctor.getName()+" saved successfully");

	}

	public void deleteDoctor(int docId) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Doctor doctor = new Doctor();
		doctor.setDocId(docId);
		session.delete(doctor);
		transaction.commit();
		session.close();
		System.out.println("movie deleted with id"+doctor.getDocId());

	}

	public void updateDoctor(Doctor doctor) {
		Session session =sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(doctor);
		transaction.commit();
		session.close();
		System.out.println("movie updated with id:" + doctor.getDocId());

	}

	public Doctor getDoctor(String doctorName) {
		Session session=sf.openSession();
		Doctor doctor=(Doctor) session.get(Doctor.class, doctorName);
		return doctor;
	}

	public List<Doctor> getAllDoctor() {
		Session session=sf.openSession();
		Query q=session.createQuery("from Doctor");
		return q.list();
	}

}
