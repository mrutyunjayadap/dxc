package com.dxc.model;

import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.search.annotations.IndexedEmbedded;
@Entity
public class Doctor {
	@Id
	private int docId;
	private String name;
	private int fees;
	@ElementCollection
	@IndexedEmbedded
	private Set<HospitalDetails> hospitalDetails;
	public Doctor(int docId, String name, int fees) {
		super();
		this.docId = docId;
		this.name = name;
		this.fees = fees;
	}
	public Doctor() {
		super();
	}
	public Doctor(int docId, String name, int fees, Set<HospitalDetails> hospitalDetails) {
		super();
		this.docId = docId;
		this.name = name;
		this.fees = fees;
		this.hospitalDetails = hospitalDetails;
	}
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	public Set<HospitalDetails> getHospitalDetails() {
		return hospitalDetails;
	}
	public void setHospitalDetails(Set<HospitalDetails> hospitalDetails) {
		this.hospitalDetails = hospitalDetails;
	}
	@Override
	public String toString() {
		return "Doctor [docId=" + docId + ", name=" + name + ", fees=" + fees + ", hospitalDetails=" + hospitalDetails
				+ "]";
	}


	

}
