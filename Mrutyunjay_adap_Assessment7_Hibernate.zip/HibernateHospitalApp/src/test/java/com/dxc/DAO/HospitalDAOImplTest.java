package com.dxc.DAO;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.dxc.model.Doctor;
import com.dxc.model.HospitalDetails;

import junit.framework.TestCase;

public class HospitalDAOImplTest extends TestCase {

	HospitalDAOImpl impl;

	protected void setUp() throws Exception {
		impl = new HospitalDAOImpl();
	}

	protected void tearDown() throws Exception {
		impl = null;
	}

	/*
	 * public void testAddDoctor() { List<Doctor> doctors = impl.getAllDoctor();
	 * 
	 * Doctor doctor = new Doctor(100, "mehul", 100); Set<HospitalDetails> hospital
	 * = new HashSet<HospitalDetails>(); hospital.add(new HospitalDetails("apollo",
	 * "Bangalore")); doctor.setHospitalDetails(hospital);
	 * 
	 * impl.addDoctor(doctor);
	 * 
	 * List<Doctor> testDoctors = impl.getAllDoctor();
	 * 
	 * impl.deleteDoctor(100); assertEquals(doctors.size() + 1, testDoctors.size());
	 * }
	 */

	/*
	 * public void testDeleteDoctor() { Doctor movie= new Doctor(); int Data1 =
	 * impl.getAllDoctor().size(); impl.deleteDoctor(102); int Data2
	 * =impl.getAllDoctor().size(); assertNotSame(Data2, Data1); }
	 */

	public void testUpdateDoctor() {
		Doctor doctor = new Doctor(3, "C", 1000); impl.addDoctor(doctor); 
		Doctor newDoctor = new Doctor(3, "d", 5000); impl.updateDoctor(newDoctor);
		 assertNotSame(newDoctor, doctor);
	}

	/*
	 * public void testGetDoctor() { Doctor doctor = new Doctor(102, "Jay", 100);
	 * Set<HospitalDetails> hospital = new HashSet<HospitalDetails>();
	 * hospital.add(new HospitalDetails("apollo", "Bangalore"));
	 * doctor.setHospitalDetails(hospital); impl.addDoctor(doctor);
	 * 
	 * Doctor doctor2 =impl.getDoctor("Jay"); assertEquals(doctor, doctor2); }
	 */

	/*
	 * public void testGetAllDoctor() { int Data = impl.getAllDoctor().size();
	 * Doctor doctor = new Doctor(5, "e", 7500); impl.addDoctor(doctor); int Data2 =
	 * impl.getAllDoctor().size(); assertNotSame(Data2, Data); }
	 */

}
