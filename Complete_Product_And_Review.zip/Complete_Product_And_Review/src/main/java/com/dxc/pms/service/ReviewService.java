package com.dxc.pms.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Reviews;

public interface ReviewService {
	public boolean addReview(int productId,Reviews review);
	public Reviews getReview(int productId,int reviewId);
	public boolean isReviewExists(int reviewId);
	public boolean deleteReview(int productId,int reviewId);
	public boolean updateReview(int productId,Reviews review);
	public Set<Reviews> getReviews(int productId);
}
