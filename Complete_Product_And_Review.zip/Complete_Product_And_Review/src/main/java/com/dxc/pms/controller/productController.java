package com.dxc.pms.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.dao.ReviewDAO;
import com.dxc.pms.model.Product;
import com.dxc.pms.model.Reviews;
import com.dxc.pms.service.ProductService;
import com.dxc.pms.service.ReviewService;

@RestController
@RequestMapping("ProductManagementSystem/product")
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:4200" })
public class productController {
	@Autowired
	ProductService productService;
	@Autowired
	ReviewService reviewService;

	// getting a single product
	@GetMapping("/{productId}")
	public ResponseEntity<Product> getProduct(@PathVariable("productId") int productId) {
		System.out.println("Get Product called" + productId);
		Product product = new Product();
		if (productService.isProductExists(productId)) {
			product = productService.getProduct(productId);
			return new ResponseEntity<Product>(product, HttpStatus.OK);
		} else {
			return new ResponseEntity<Product>(product, HttpStatus.NO_CONTENT);
		}

	}

	// getting review
	@GetMapping("/{productId}/reviews/{reviewId}")
	public ResponseEntity<Reviews> getReview(@PathVariable("productId") int productId,@PathVariable("reviewId") int reviewId) {
		System.out.println("Get Review called");
		Reviews review = new Reviews();
		review = reviewService.getReview(productId, reviewId);
		return new ResponseEntity<Reviews>(review, HttpStatus.OK);
	}

	// deleting product
	@DeleteMapping("/{productId}")

	public ResponseEntity<Product> deleteProduct(@PathVariable("productId") int productId) {
		System.out.println("Delete Product called" + productId);

		if (productService.isProductExists(productId)) {
			productService.deleteProduct(productId);
			return new ResponseEntity<Product>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}

	}

	// Delete review
	@DeleteMapping("/{productId}/reviews/{reviewId}")
	public ResponseEntity<Reviews> deleteReview(@PathVariable("productId") int productId,@PathVariable("reviewId") int reviewId) {
		System.out.println("Delete Review called" + reviewId);
		reviewService.deleteReview(productId, reviewId);
		return new ResponseEntity<Reviews>(HttpStatus.NO_CONTENT);
	}

	// get all products
	@GetMapping
	public ResponseEntity<List<Product>> getAllProducts() {
		System.out.println("Get All Products called");
		List<Product> allProducts = productService.getProducts();
		return new ResponseEntity<List<Product>>(allProducts, HttpStatus.OK);
	}

	// Get all reviews
	@GetMapping("/{productId}/reviews")
	public ResponseEntity<Set<Reviews>> getAllReviews(@PathVariable("productId") int productId) {
		System.out.println("Get All Reviews called");
		Set<Reviews> allReviews = reviewService.getReviews(productId);
		return new ResponseEntity<Set<Reviews>>(allReviews, HttpStatus.OK);
	}

	// Add product
	@PostMapping
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		System.out.println("Add Product called");
		System.out.println(product);
		if (productService.isProductExists(product.getProductId())) {
			return new ResponseEntity<Product>(product, HttpStatus.CONFLICT);
		} else {
			productService.addProduct(product);
			return new ResponseEntity<Product>(product, HttpStatus.CREATED);
		}

	}

	// Add review
	@PostMapping("/{productId}/reviews")
	public ResponseEntity<Reviews> addReview(@PathVariable("productId") int productId, @RequestBody Reviews review) {
		System.out.println("Add reviews called");
		System.out.println(review);
		if (reviewService.isReviewExists(review.getReviewId())) {
			return new ResponseEntity<Reviews>(review, HttpStatus.CONFLICT);
		} else {
			reviewService.addReview(productId, review);
			return new ResponseEntity<Reviews>(review, HttpStatus.CREATED);
		}

	}

	// Update product
	@PutMapping
	public ResponseEntity<Product> updateProduct(@RequestBody Product product) {
		System.out.println("Update Product called");
		System.out.println(product);
		if (productService.isProductExists(product.getProductId())) {
			productService.updateProduct(product);
			return new ResponseEntity<Product>(product, HttpStatus.OK);
		} else {
			return new ResponseEntity<Product>(product, HttpStatus.NO_CONTENT);
		}
	}

	// Update review
	@PutMapping("/{productId}/reviews")
	public ResponseEntity<Reviews> updateReview(@PathVariable("productId") int productId, @RequestBody Reviews review) {
		System.out.println("Update Review called");
		reviewService.updateReview(productId, review);
		return new ResponseEntity<Reviews>(review, HttpStatus.OK);
	}

	@GetMapping("/search/{productName}")
	public ResponseEntity<List<Product>> searchProduct(@PathVariable("productName") String productName) {
		System.out.println("Search ProductByName called" + productName);
		List<Product> allProducts = productService.searchProductByName(productName);
		return new ResponseEntity<List<Product>>(allProducts, HttpStatus.OK);
	}

}
