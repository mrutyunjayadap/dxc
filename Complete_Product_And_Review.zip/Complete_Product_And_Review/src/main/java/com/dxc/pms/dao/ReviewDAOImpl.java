package com.dxc.pms.dao;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Reviews;
import com.dxc.pms.service.ProductService;
import com.dxc.pms.service.ReviewService;
import com.mongodb.WriteResult;

@Repository
public class ReviewDAOImpl implements ReviewDAO {
	@Autowired
	MongoTemplate template;
	@Autowired
	ProductService productService;
	@Autowired
	ReviewService reviewService;

	@Override
	public boolean addReview(int productId, Reviews review) {
		System.out.println("Inside DAOImpl" + review);
		Product product = productService.getProduct(productId);
		product.getProductReviews().add(review);
		template.save(product);
		template.save(review);
		return false;
	}

	@Override
	public Reviews getReview(int productId, int reviewId) {
		Product product = productService.getProduct(productId);
		Set<Reviews> allReviews = (Set<Reviews>) product.getProductReviews();
		for (Reviews x : allReviews) {
			if (reviewId == x.getReviewId()) {
				return x;
			} else {
				continue;
			}
		}
		return null;

	}

	@Override
	public boolean isReviewExists(int reviewId) {
		Reviews review = template.findById(reviewId, Reviews.class, "review");
		if (review == null)
			return false;
		else
			return true;
	}

	@Override
	public boolean deleteReview(int productId, int reviewId) {
		Product product = productService.getProduct(productId);
		Set<Reviews> allReviews = (Set<Reviews>) product.getProductReviews();
		allReviews = product.getProductReviews();
		System.out.println(allReviews);
		for (Reviews x : allReviews) {
			if (reviewId == x.getReviewId()) {
				System.out.println(x);
				allReviews.remove(x);
				product.setProductReviews(allReviews);
				template.save(product, "product");

			} else {
				continue;
			}

		}
		return true;

	}

	@Override
	public boolean updateReview(int productId, Reviews review) {
		Product product = productService.getProduct(productId);
		System.out.println("2");
		WriteResult writeResult = null;
		Set<Reviews> allReviews = (Set<Reviews>) product.getProductReviews();
		for (Reviews x : allReviews) {
			if (review.getReviewId() == x.getReviewId()) {
				System.out.println(x);
				System.out.println("3");
				allReviews.remove(x);
				product.setProductReviews(allReviews);
				product.getProductReviews().add(review);
				template.save(product, "product");
				break;
			} else {
				continue;
			}
		}

		return true;
	}

	@Override
	public Set<Reviews> getReviews(int productId) {
		Product product = productService.getProduct(productId);

		System.out.println(product.getProductReviews());
		Set<Reviews> r = product.getProductReviews();
		return r;
	}

}
