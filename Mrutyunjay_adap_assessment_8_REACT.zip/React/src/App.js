import React, { Component } from "react";
import ListProductComponent from "./components/ListProductComponent";
import "bootstrap/dist/css/bootstrap.css";
import {Switch,Route} from 'react-router-dom';
import {BrowserRouter as Router} from 'react-router-dom';
import ProductComponent from "./components/ProductComponent";
import SearchComponent from "./components/SearchComponent";
import DisplayResult from "./components/DisplayResult";
class App extends Component {
  render() {
    return (
      <div>
        <center><h1>My product App</h1></center>
        <Router>
          <Switch>
          <Route exact path="/" component={ListProductComponent}></Route>
          <Route exact path="/products" component={ListProductComponent}></Route>
          <Route exact path="/productSearch/:prodName" component={DisplayResult}></Route>
          <Route exact path="/productSearch" component={SearchComponent}></Route>
          <Route exact path="/productsAdd/:prodId" component={ProductComponent}></Route>
          </Switch>
        </Router>
      </div>
    );
  }
}

export default App;
