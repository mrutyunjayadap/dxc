import React, { Component } from "react";
import ProductDataService from "../service/ProductDataService";

class ListProductComponent extends Component {
  constructor(props) {
    super(props);
    this.refreshProduct = this.refreshProduct.bind(this);
    this.deleteProductClicked = this.deleteProductClicked.bind(this);
    this.updateProductClicked = this.updateProductClicked.bind(this);
    this.addProductClicked = this.addProductClicked.bind(this);
    this.searchProductClicked=this.searchProductClicked.bind(this);

    this.state = {
      products: [],
      message: ""
    };
  }
  componentWillMount() {
    this.refreshProduct();
  }
  refreshProduct() {
    ProductDataService.getAllProducts().then(response => {
      this.setState({
        products: response.data
      });
    });
  }

  deleteProductClicked(productIdToDelete) {
    ProductDataService.deleteProduct(productIdToDelete).then(response => {
      this.setState({
        message: `Delete product ${productIdToDelete} successfully`
      });
      this.refreshProduct();
    });
  }
  updateProductClicked(productId) {
    this.props.history.push(`/productsAdd/${productId}`);
  }
  addProductClicked() {
    this.props.history.push(`/productsAdd/Add`);
  }
  searchProductClicked(){
    this.props.history.push(`/productSearch`);
  }
  render() {
    return (
      <div>
        <div className="container">
          {this.state.message && (
            <div className="alert alert-success">{this.state.message}</div>
          )}
          <h2>
            <center>All Products</center>
          </h2>
          <table className="table">
            <thead>
              <tr>
                <th>Product Id</th>
                <th>Product Name</th>
                <th>QuantityOnHand</th>
                <th>Price</th>
                <th>Update</th>
                <th>Delete</th>
              </tr>
            </thead>

            <tbody>
              {this.state.products.map(product => (
                <tr key={product.productId}>
                  <td>{product.productId}</td>
                  <td>{product.productName}</td>
                  <td>{product.quantityOnHand}</td>
                  <td>{product.price}</td>
                  <td>
                    <button
                      className="btn btn-warning"
                      onClick={() =>
                        this.updateProductClicked(product.productId)
                      }
                    >
                      Update
                    </button>
                  </td>
                  <td>
                    <button
                      className="btn btn-danger"
                      onClick={() =>
                        this.deleteProductClicked(product.productId)
                      }
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
              <tr>
                <td>
                <button
                  className="btn btn-success"
                  onClick={() => this.addProductClicked()}
                >
                  Add Product
                </button>
                </td>
                <td>
                <button
                  className="btn btn-primary"
                  onClick={() => this.searchProductClicked()}
                >
                  Search Product
                </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListProductComponent;
