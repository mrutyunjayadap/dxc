import React, { Component } from "react";
import ProductDataService from "../service/ProductDataService";
import { Formik, Form, Field, ErrorMessage } from "formik";
class ProductComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      productId: this.props.match.params.prodId,
      productName: "",
      quantityOnHand: "",
      price: "",
      boolean: false,
      text: "Add"
    };
    this.onsubmit = this.onsubmit.bind(this);
  }
  componentWillMount() {
    //if (this.setState.productId === "Add") return;

    ProductDataService.getProduct(this.state.productId).then(response => {
      this.setState({
        productName: response.data.productName,
        quantityOnHand: response.data.quantityOnHand,
        price: response.data.price,
        boolean: true,
        text: "Update",
      });
    });
  }
  onsubmit(product) {
    if (this.state.productId === "Add") {
      ProductDataService.addProduct(product).then(response => {
        this.props.history.push(`/products`);
      });
    } else {
      ProductDataService.updateProduct(product).then(() =>
        this.props.history.push(`/products`)
      );
    }
    console.log(product);
  }

  validateProductForm(values) {
    let errors = {};
    if (!values.productName) {
      errors.productName = "Please enter a product Name";
    }
    if (values.productName < 5) {
      errors.productName = "Please enter atleast 5 characters in productName";
    } else if (!values.quantityOnHand) {
      errors.quantityOnHand = "Please enter quantityOnHand";
    } else if (!values.price) {
      errors.price = "Please enter price";
    } else if (values.price < 0) {
      errors.price = "Price cannot be Negative";
    }
    return errors;
  }
  render() {
    let { productId, productName, quantityOnHand, price } = this.state;
    return (
      <div className="container">
        <center>
          <h3>Product to {this.state.text}</h3>
        </center>
        <Formik
          initialValues={{
            productId,
            productName,
            quantityOnHand,
            price
          }}
          enableReinitialize={true}
          onSubmit={this.onsubmit}
          validateOnChange={false}
          validateOnBlur={false}
          validate={this.validateProductForm}
        >
          <Form>
            <ErrorMessage
              name="productId"
              component="div"
              className="alert alert-warning"
            ></ErrorMessage>
            <ErrorMessage
              name="productName"
              component="div"
              className="alert alert-warning"
            ></ErrorMessage>
            <ErrorMessage
              name="quantityOnHand"
              component="div"
              className="alert alert-warning"
            ></ErrorMessage>
            <ErrorMessage
              name="price"
              component="div"
              className="alert alert-warning"
            ></ErrorMessage>

            <fieldset className="form-group">
              <label>Product Id</label>
              <Field
                className="form-control"
                type="text"
                name="productId"
                disabled={this.state.boolean}
              ></Field>
            </fieldset>
            <fieldset className="form-group">
              <label>Product Name</label>
              <Field
                className="form-control"
                type="text"
                name="productName"
              ></Field>
            </fieldset>
            <fieldset className="form-group">
              <label>QuantityOnHand</label>
              <Field
                className="form-control"
                type="text"
                name="quantityOnHand"
              ></Field>
            </fieldset>
            <fieldset className="form-group">
              <label>Price</label>
              <Field className="form-control" type="text" name="price"></Field>
            </fieldset>

            <button className="btn btn-success" type="submit">
              {this.state.text}
            </button>
          </Form>
        </Formik>
      </div>
    );
  }
}

export default ProductComponent;
