package com.relationship;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.ogm.cfg.OgmConfiguration;

public class Client {
	public static void main(String[] args) {

		OgmConfiguration cfg = new OgmConfiguration();
		cfg.configure();

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Transaction tx = session.beginTransaction();

		// create a Person
		Person ahmed = new Person("Tufail", "Ahmed");

		// and two hikes

		HikeSection section1 = new HikeSection("NandiHills", "Bangalore");
		HikeSection section2 = new HikeSection("Place1", "Mysore");
		HikeSection section3 = new HikeSection("Place2", "Mandya");
		List<HikeSection> allSection1 = new ArrayList<HikeSection>();
		allSection1.add(section1);
		allSection1.add(section2);
		allSection1.add(section3);

		HikeSection newSection1 = new HikeSection("Jogfalls", "Nagpur");
		HikeSection newSection2 = new HikeSection("FogFalls", "Pune");
		List<HikeSection> allSection2 = new ArrayList<HikeSection>();
		allSection2.add(newSection1);
		allSection2.add(newSection2);

		Hike hike1 = new Hike("Karnataka", new Date(), new BigDecimal("5.5"), allSection1);

		Hike hike2 = new Hike("Maharshtra", new Date(), new BigDecimal("7.5"), allSection2);

		hike1.setOrganizer(ahmed);
		ahmed.getOrganizedHikes().add(hike1);

		hike2.setOrganizer(ahmed);
		ahmed.getOrganizedHikes().add(hike2);

		session.save(hike1);
		session.save(hike2);
		session.save(ahmed);

		tx.commit();
		System.out.println("Saved .. One to Many ");

	}
}
