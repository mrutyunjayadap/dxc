package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbcon.DBconnection;

public class UserDAOImpl implements UserDAO{
	Connection connection = DBconnection.getConnection();
	
	private static final String FETCH_USER_ALL = "select* from user";
	private static final String FETCH_USER = "select* from user where username=? AND password=?";

	
	

	@Override
	public boolean validate(String username,String password) {
		boolean userExists = false;
		PreparedStatement prepareStatement;
		try {
			prepareStatement = connection.prepareStatement(FETCH_USER);
			prepareStatement.setString(1, username);
			prepareStatement.setString(2, password);
			ResultSet res = prepareStatement.executeQuery();
			if (res.next()) {
				userExists = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userExists;
	}

	
	



}
