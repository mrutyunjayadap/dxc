package dao;

public interface UserDAO {
	public boolean validate(String username,String password);
}
