package dao;

import java.util.List;
import userModel.Training;

public interface TrainingDAO {
	public List<Training> displayRecords();
	public void updateRecord(int sapId, int percentage);

}
