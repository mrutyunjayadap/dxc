package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dbcon.DBconnection;
import userModel.Training;

public class TrainingDAOImpl implements TrainingDAO{
	Connection connection = DBconnection.getConnection();
	List<Training> allRecords = new ArrayList<Training>();
	
	private static final String FETCH_RECORD_ALL = "select* from training";
	private static final String RECORD_UPDATE_QUERY = "update training set percentage=? where sapId=?";

	@Override
	public List<Training> displayRecords() {
		List<Training> allRecords = new ArrayList<Training>();

		ResultSet res;
		try {
			Statement stat = connection.createStatement();
			res = stat.executeQuery(FETCH_RECORD_ALL);
			while (res.next()) {
				Training training = new Training();
				training.setSapId(res.getInt(1));
				training.setEmployeeName(res.getString(2));
				training.setStream(res.getString(3));
				training.setPercentage(res.getInt(4));
				allRecords.add(training);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return allRecords;
	}



	@Override
	public void updateRecord(int sapId, int percentage) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(RECORD_UPDATE_QUERY);
			preparedStatement.setInt(1, percentage);
			preparedStatement.setInt(2, sapId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
