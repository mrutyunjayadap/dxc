package userModel;

public class Training {
	int sapId;
	String employeeName;
	String stream;
	int percentage;
	public Training(int sapId, String employeeName, String stream, int percentage) {
		super();
		this.sapId = sapId;
		this.employeeName = employeeName;
		this.stream = stream;
		this.percentage = percentage;
	}
	public Training() {
		super();
	}
	@Override
	public String toString() {
		return "\nTraining [sapId=" + sapId + ", employeeName=" + employeeName + ", stream=" + stream + ", percentage="
				+ percentage + "]";
	}
	public int getSapId() {
		return sapId;
	}
	public void setSapId(int sapId) {
		this.sapId = sapId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

}
