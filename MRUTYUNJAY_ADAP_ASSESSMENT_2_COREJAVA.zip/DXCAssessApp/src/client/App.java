package client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import dao.TrainingDAO;
import dao.TrainingDAOImpl;
import dao.UserDAO;
import dao.UserDAOImpl;
import userModel.Training;


public class App {

	UserDAO userDAO;
	String username;
	String password;
	int sapId;
	String employeeName;
	String stream;
	int percentage;
	int choice;
	Scanner scanner = new Scanner(System.in);

	public void launchApp() {
		UserDAO userDAO = new UserDAOImpl();
		System.out.println("Please enter username:");
		username = scanner.next();
		System.out.println("Please enter password:");
		password = scanner.next();
		if (userDAO.validate(username, password)) {
			System.out.println("User authenticated.");
			
		} else {
			System.out.println("User cannot be authenticated");
			System.exit(0);
		}
		while (true) {
			System.out.println("M E N U ");
			System.out.println("1. Display All Training Records : ");
			System.out.println("2. Display Records one by One and update the percentage : ");
			System.out.println("3. E X I T ");
			Scanner scanner = new Scanner(System.in);

			System.out.println("Please enter your choice : (1-3)");
			choice = scanner.nextInt();
			TrainingDAO trainingDAO = new TrainingDAOImpl();

			switch (choice) {
			case 1:

				System.out.println(trainingDAO.displayRecords());

				break;

			case 2:
				List<Training> record = new ArrayList<Training>();
				record=trainingDAO.displayRecords();
				Iterator<Training>iterator=record.iterator();
				while(iterator.hasNext()) {
					Training training =new Training();
					training=iterator.next();
					System.out.println(training.toString());
					if(training.getPercentage()==0) {
						System.out.println("enter percentage");
						percentage=scanner.nextInt();
						trainingDAO.updateRecord(training.getSapId(),percentage);
					}
					else {
						System.out.println("percentage already entered");
					}
				}
					
			}
		}

	}

}
