package client;

import java.util.Scanner;

import dao.PassengerDAO;
import dao.PassengerDAOImpl;
import passengerModel.Passenger;

public class Main {
 
    public Main() {
        // TODO Auto-generated constructor stub
    }
 
    public static void main(String[] args) {
        PassengerDAO passengerDAO = new PassengerDAOImpl();
        while (true) {
            System.out.println("M E N U ");
            System.out.println("1. Add The Passsenger : ");
            System.out.println("2. Get All The Passenger : ");
            System.out.println("3. E X I T");
            Scanner scanner = new Scanner(System.in);
            int choice = 0;
            System.out.println("Please enter your choice : (1-3)");
            choice = scanner.nextInt();
 
            switch (choice) {
            case 1:
                System.out.println("Please enter PNR Number :");
                int pnrNumber = scanner.nextInt();
                System.out.println("Please enter passenger Name  :");
                String passengerName = scanner.next();
                System.out.println("Please enter start :");
                String start = scanner.next();
                System.out.println("Please enter  fare :");
                int fare = scanner.nextInt();
 
                Passenger passenger = new Passenger(pnrNumber, passengerName, start, fare);
 
               passengerDAO.addPassenger(passenger);
                break;
            case 2:
 
                System.out.println(passengerDAO.getAllPassenger());
                break;
            case 3:
                System.out.println("Thanks for using my app");
                System.exit(0);
            default:
                System.out.println("R U drunk milk. Please enter (1-3)");
            }
        }
 
    }
}
