package dao;

import java.util.List;

import passengerModel.Passenger;

public interface PassengerDAO {
	public Passenger getPnrNumber(int pnrNumber);
	public List<Passenger> getAllPassenger();
	public void addPassenger(Passenger passenger);
	public void deletePassenger(int pnrNumber);
	public void updatePassenger(Passenger passenger);
}
