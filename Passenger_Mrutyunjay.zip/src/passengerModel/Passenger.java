package passengerModel;

public class Passenger {
	private int pnrNumber;
	private String passengerName;
	private String start;
	private String destination;
	private int fare;
	public Passenger() {
		super();
	}
	public Passenger(int pnrNumber, String passengerName, String start, int fare) {
		super();
		this.pnrNumber = pnrNumber;
		this.passengerName = passengerName;
		this.start = start;

		this.fare = fare;
	}
	public int getPnrNumber() {
		return pnrNumber;
	}
	public void setPnrNumber(int pnrNumber) {
		this.pnrNumber = pnrNumber;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	@Override
	public String toString() {
		return "Passenger [pnrNumber=" + pnrNumber + ", passengerName=" + passengerName + ", start=" + start
				+ ", fare=" + fare + "]";
	}
	
}
